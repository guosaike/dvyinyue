<template>
  <div class="user-center">
    <div class="user-left">
      <!-- 头像 -->
      <div class="box-item">
        <div style="display: flex;align-items: center;">
          <el-avatar :size="50" src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png" />
          <div style="flex: 1;margin-left:10px;">
            <div class="user-name">B站程序员科科</div>
          </div>
        </div>
      </div>

      <!-- 订单中心 -->
      <div class="box-item" style="border-top: 1px solid #cedce4;border-bottom: 1px solid #cedce4;">
        <!-- <div class="item-title">订单中心</div>
        <div @click="$router.push('/home/usercenter/order')" class="nav-row" style="border-top: none;">
          <el-icon>
            <List />
          </el-icon>
          <span class="nav-text">我的订单</span>
        </div> -->
        <div @click="$router.push('/home/usercenter/sc')" class="nav-row">
          <el-icon>
            <Link />
          </el-icon>
          <span class="nav-text">我的收藏</span>
        </div>
        <div @click="$router.push('/home/usercenter/pl')" class="nav-row">
          <el-icon>
            <Link />
          </el-icon>
          <span class="nav-text">我的评论</span>
        </div>
        <div @click="$router.push('/home/usercenter/dz')" class="nav-row">
          <el-icon>
            <Link />
          </el-icon>
          <span class="nav-text">我的地址</span>
        </div>
      </div>

      <!-- 个人设置 -->
      <div class="box-item">
        <div class="item-title">个人设置</div>
        <div @click="$router.push('/home/usercenter/zl')" class="nav-row" style="border-top: none;">
          <el-icon>
            <Odometer />
          </el-icon>
          <span class="nav-text">编辑资料</span>
        </div>
        <!-- <div class="nav-row">
          <el-icon>
            <Lock />
          </el-icon>
          <span class="nav-text">账号安全</span>
        </div> -->
      </div>
    </div>
    <div class="user-right">
      <RouterView />
    </div>
  </div>
</template>

<style>
.user-center {
  display: flex;
  padding-top: 20px;
}

.user-left {
  height: fit-content;
  width: 235px;
  margin-right: 20px;
  border: 1px solid #cedce4;
  box-size: border-box;
}

.user-right {
  flex: 1;
}

.box-item {
  padding: 20px;
  box-size: border-box;
}

.item-title {
  color: #152844;
  font-weight: 600;
  font-size: 14px;
  line-height: 18px;
  margin-bottom: 8px;
}

.user-name {
  color: #152844;
  font-weight: 600;
  font-size: 18px;
  line-height: 24px;
  text-overflow: ellipsis;
  white-space: nowrap;
  margin: 0;
  overflow: hidden;
}

.hy-text {
  font-size: 12px;
  color: #6f6f6f;
  line-height: 16px;
  margin-top: 8px;
}

.f-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  font-size: 16px;
  line-height: 16px;
  color: #6f6f6f;
}

.num-text {
  line-height: 18px;
  color: #152844;
  font-weight: 600;
  font-size: 14px;
  margin-top: 4px;
}

.nav-row {
  padding: 20px 0;
  border-top: 1px dashed #cedce4;
  color: #1890ff;
  font-size: 16px;
  display: flex;
  align-items: center;
  cursor: pointer;
}

.nav-text {
  color: #152844;
  font-size: 14px;
  margin-left: 10px;
}
</style>